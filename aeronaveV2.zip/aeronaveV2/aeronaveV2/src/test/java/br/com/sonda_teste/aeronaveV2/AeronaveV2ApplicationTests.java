package br.com.sonda_teste.aeronaveV2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AeronaveV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
