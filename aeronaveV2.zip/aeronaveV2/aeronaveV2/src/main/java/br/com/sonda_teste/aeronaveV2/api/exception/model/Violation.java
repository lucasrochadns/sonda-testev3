package br.com.sonda_teste.aeronaveV2.api.exception.model;

public record Violation(
        String field, String message
) {
}
