package br.com.sonda_teste.aeronaveV2.domain.model;

public enum Fabricante {
    EMBRAER,
    BOEING,
    AIRBUS
}
