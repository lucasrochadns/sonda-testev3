package br.com.sonda_teste.aeronaveV2.infra.persistence;

/*
* Projeção read model Decada
* */
public interface DecadaCountProjection {

    Integer getDecada();
    Long getTotal();
}
