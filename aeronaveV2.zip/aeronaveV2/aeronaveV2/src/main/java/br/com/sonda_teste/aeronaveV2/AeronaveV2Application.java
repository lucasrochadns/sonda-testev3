package br.com.sonda_teste.aeronaveV2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeronaveV2Application {

	public static void main(String[] args) {
		SpringApplication.run(AeronaveV2Application.class, args);
	}

}
