package br.com.sonda_teste.aeronaveV2.domain.model;

public record DecadaSummary(long decada, long total) {
}
